import React from "react";
import { Helmet } from "react-helmet-async";
import Hero from "./section/Hero";
import Services from "./services/Services";
import Footer from "./footer/footer";
import About from "./about/About";
import Blog from "./blog/Blog";
import Devices from "./device/device";
import Reviews from "components/reviews/reviews";

const Home = () => {
  return (
    <>
      <Helmet>
        <title>Sanethica | Sağlıklı Yaşam & Beslenme</title>
        <meta
          name="description"
          content="Sanethica ile sağlıklı yaşama adım atın. Diyet, şekillenme ve wellness alanlarında uzman kadro ile yanınızdayız."
        />
        <meta
          name="keywords"
          content="Sanethica, diyet, beslenme, sağlıklı yaşam, wellness"
        />
      </Helmet>

      <Hero />
      <About />
      <Devices />
      <Services />
      <Blog />
      <Footer />
      <Reviews />
    </>
  );
};

export default Home;
